# -*- coding: utf-8 -*-
# @Author  : Zhao Yutao
# @Time    : 2025/7/15 19:58
# @Function: 
# @mails: zhaoyutao22@mails.ucas.ac.cn
class EmailMonitorConfigError(Exception):
    """邮件监控配置错误"""
    pass