# -*- coding: utf-8 -*-
# @Author  : Zhao Yutao
# @Time    : 2025/7/15 20:05
# @Function: 测试代码
# @mails: zhaoyutao22@mails.ucas.ac.cn

count = 1000
while 1:
    print(1000/count)
    count = count - 1